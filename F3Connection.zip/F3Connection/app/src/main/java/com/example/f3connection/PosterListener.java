package com.example.f3connection;

public interface PosterListener {
    void onPosterAction(Boolean isSelected);

}

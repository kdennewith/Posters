package com.example.f3connection;

public class Poster {
    String name, createdBy, story;
    int image;
    Boolean isSelected = false;
    float rating;
}
